import json
import os

if os.path.exists("estoque.json"):
    with open("estoque.json", "r", encoding="utf-8") as f:
        estoque = json.load(f)
else:
    estoque = []

def salvar():
    with open("estoque.json", "w", encoding="utf-8") as f:
        json.dump(estoque, f, indent=2, ensure_ascii=False)


def cadastrar_produto():
    produto = input("Digite o nome do produto: ")
    estoque.append(produto)
    salvar()
    print("Produto cadastrado com sucesso!")

def consultar_produtos():
    print("Produtos no estoque:")
    salvar()
    for i, produto in enumerate(estoque, 1):
        print(f"{i}. {produto}")

def atualizar_produto():
    consultar_produtos()
    i = int(input("Escolha o número do produto que deseja atualizar: ")) - 1
    if 0 <= i < len(estoque):
        novo_produto = input("Digite o nome do novo produto: ")
        estoque[i] = novo_produto
        salvar()
        print("Produto atualizado com sucesso!")
    else:
        print("Número inválido.")

def deletar_produto():
    consultar_produtos()
    i = int(input("Escolha o número do produto que deseja deletado: ")) - 1
    if 0 <= i < len(estoque):
        estoque.pop(i)
        salvar()
        print("Produto deletado com sucesso!")
    else:
        print("Número inválido.")

def menu():
    while True:
        print("Menu:")
        print("1. Cadastrar Produto")
        print("2. Consultar Produtos")
        print("3. Atualizar Produto")
        print("4. Deletar Produto")
        print("5. Sair")
        opção = input("Escolha uma opção: ")
        if opção == "1":
            cadastrar_produto()
        elif opção == "2":
            consultar_produtos()
        elif opção == "3":
            atualizar_produto()
        elif opção == "4":
            deletar_produto()
        elif opção == "5":
            print("Saindo...")
            break
        else:
            print("Opção inválida.")

menu()